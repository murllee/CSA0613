import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("results.csv")
main = df[df.tag == "main"]
stress = df[df.tag == "stress"]
agg = main.groupby("n")[["dp_time_s", "greedy_time_s", "hybrid_time_s"]].mean()

# 1. Execution time vs input size
plt.figure(figsize=(6.5, 4.2))
plt.plot(agg.index, agg.dp_time_s, "o-", label="DP (exact, baseline)")
plt.plot(agg.index, agg.greedy_time_s, "s-", label="Greedy (baseline)")
plt.plot(agg.index, agg.hybrid_time_s, "^-", label="PFB-DP (developed)")
plt.xlabel("Number of packages (n)")
plt.ylabel("Mean execution time (s)")
plt.title("Execution Time vs Input Size")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("chart_time_vs_n.png", dpi=150)
plt.close()

# 2. Optimality gap: greedy vs hybrid
gap = main.groupby("n")[["greedy_gap_pct", "hybrid_gap_pct"]].mean()
plt.figure(figsize=(6.5, 4.2))
plt.plot(gap.index, gap.greedy_gap_pct, "s-", label="Greedy gap vs DP-optimal")
plt.plot(gap.index, gap.hybrid_gap_pct, "^-", label="PFB-DP gap vs DP-optimal")
plt.xlabel("Number of packages (n)")
plt.ylabel("Optimality gap (%)")
plt.title("Solution-Quality Gap vs DP-Optimal")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("chart_gap_vs_n.png", dpi=150)
plt.close()

# 3. Candidate pool reduction vs n
cand = main.groupby("n")["candidate_reduction_pct"].mean()
plt.figure(figsize=(6.5, 4.2))
plt.bar(cand.index.astype(str), cand.values, color="#4C72B0")
plt.xlabel("Number of packages (n)")
plt.ylabel("Candidate pool reduction (%)")
plt.title("PFB-DP Candidate-Pool Reduction Before DP Stage")
plt.grid(alpha=0.3, axis="y")
plt.tight_layout()
plt.savefig("chart_candidate_reduction.png", dpi=150)
plt.close()

# 4. Speedup at large scale (stress test)
plt.figure(figsize=(6.5, 4.2))
labels = [f"n={r.n}\ncap={r.capacity}" for r in stress.itertuples()]
x = range(len(stress))
plt.bar(x, stress.dp_time_s, width=0.35, label="DP (exact)", align="edge")
plt.bar([i + 0.35 for i in x], stress.hybrid_time_s, width=0.35, label="PFB-DP", align="edge")
plt.xticks([i + 0.35 for i in x], labels)
plt.ylabel("Execution time (s)")
plt.title("Large-Capacity Scalability Stress Test")
plt.legend()
plt.grid(alpha=0.3, axis="y")
plt.tight_layout()
plt.savefig("chart_stress_test.png", dpi=150)
plt.close()

print("Charts saved.")
