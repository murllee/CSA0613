import numpy as np
import pandas as pd
from algorithms import generate_dataset, dp_knapsack, greedy_selection, pfb_dp, measure

SIZES = [100, 500, 1000, 5000, 10000]
CAPACITIES = [500, 1000, 2500, 5000]
CONDITIONS = ["normal", "high_priority", "capacity_constrained"]
STRESS_SIZES = [5000, 10000]
STRESS_CAPACITIES = [20000, 50000]


def run_case(n, capacity, condition, df, tag):
    weights = df["weight_kg"].to_numpy()
    values = df["value"].to_numpy()
    priority = df["priority"].to_numpy()
    deadline = df["deadline_hrs"].to_numpy()

    w, v, p, d = weights.copy(), values.copy(), priority.copy(), deadline.copy()
    cap = capacity
    if condition == "high_priority":
        v = v * (1 + 0.3 * (p - 1))
    elif condition == "capacity_constrained":
        cap = int(capacity * 0.5)

    (dp_val, dp_sel), dp_t, dp_mem = measure(dp_knapsack, w, v, cap)
    dp_weight = w[dp_sel].sum() if dp_sel else 0

    (g_val, g_sel), g_t, g_mem = measure(greedy_selection, w, v, p, d, cap)
    g_weight = w[g_sel].sum() if g_sel else 0

    (h_val, h_sel, bucket, ncand), h_t, h_mem = measure(pfb_dp, w, v, p, d, cap)
    h_weight = w[h_sel].sum() if h_sel else 0

    gap_greedy = (dp_val - g_val) / dp_val * 100 if dp_val > 0 else np.nan
    gap_hybrid = (dp_val - h_val) / dp_val * 100 if dp_val > 0 else np.nan

    row = {
        "tag": tag, "n": n, "capacity": capacity, "eff_capacity": cap, "condition": condition,
        "dp_value": dp_val, "dp_time_s": dp_t, "dp_mem_mb": dp_mem,
        "dp_weight": dp_weight, "dp_selected": len(dp_sel),
        "greedy_value": g_val, "greedy_time_s": g_t, "greedy_mem_mb": g_mem,
        "greedy_weight": g_weight, "greedy_selected": len(g_sel),
        "hybrid_value": h_val, "hybrid_time_s": h_t, "hybrid_mem_mb": h_mem,
        "hybrid_weight": h_weight, "hybrid_selected": len(h_sel),
        "hybrid_bucket": bucket, "hybrid_candidates": ncand,
        "greedy_gap_pct": gap_greedy, "hybrid_gap_pct": gap_hybrid,
        "greedy_util_pct": g_weight / cap * 100,
        "hybrid_util_pct": h_weight / cap * 100,
        "dp_util_pct": dp_weight / cap * 100,
        "candidate_reduction_pct": (1 - ncand / n) * 100,
        "dp_speedup_x": dp_t / h_t if h_t > 0 else np.nan,
    }
    print(f"[{tag:6s}] n={n:6d} cap={cap:6d} cond={condition:22s} "
          f"DP={dp_val:12.1f} (t={dp_t:.4f}s) "
          f"Greedy={g_val:12.1f} (t={g_t:.4f}s) "
          f"Hybrid={h_val:12.1f} (t={h_t:.4f}s, cand={ncand}, bucket={bucket}, "
          f"speedup={row['dp_speedup_x']:.1f}x)")
    return row


rows = []
for n in SIZES:
    df = generate_dataset(n, seed=42)
    for capacity in CAPACITIES:
        for condition in CONDITIONS:
            rows.append(run_case(n, capacity, condition, df, "main"))

for n in STRESS_SIZES:
    df = generate_dataset(n, seed=42)
    for capacity in STRESS_CAPACITIES:
        rows.append(run_case(n, capacity, "normal", df, "stress"))

results = pd.DataFrame(rows)
results.to_csv("results.csv", index=False)
print("\nSaved results.csv:", results.shape)
